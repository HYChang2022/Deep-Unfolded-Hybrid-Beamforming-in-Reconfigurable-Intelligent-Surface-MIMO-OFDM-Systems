### Welcome to the Manopt GIT repository ###

Manopt is a Matlab toolbox for optimization on manifolds. For a description of the project, documentation, examples and more, see:

[http://www.manopt.org](http://www.manopt.org).

### How do I get the latest code? ###

Manopt is released in numbered versions from time to time. For most users, it is easiest to download the latest numbered version from

[http://www.manopt.org/downloads.html](http://www.manopt.org/downloads.html).

Alternatively, you can get the latest version of the code from GitHub directly of course.

Contributions are welcome!

Cheers,

Nicolas and Bamdev
