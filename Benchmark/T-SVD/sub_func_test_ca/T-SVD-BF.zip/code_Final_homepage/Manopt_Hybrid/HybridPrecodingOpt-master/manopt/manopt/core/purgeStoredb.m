function storedb = purgeStoredb(storedb, storedepth) %#ok<INUSD>

    error('This file was removed from Manopt. Please use the StoreDB class.');

end
