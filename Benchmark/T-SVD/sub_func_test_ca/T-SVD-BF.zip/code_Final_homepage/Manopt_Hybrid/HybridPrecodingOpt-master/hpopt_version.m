function [version, release_date] = hpopt_version()
    version         = '1.1.0';
    release_date    = '02-July-2018';
end


